package walluiz.chaze.lukiles;

import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

import walluiz.chaze.lukiles.walluiz.R;

public class duringPlay extends AppCompatActivity {
    private TextView tv_timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_during_play);

        tv_timer = (TextView)findViewById(R.id.tv_timer);

        new CountDownTimer(40000, 1000){
            public void onTick(long millisUntilFinished){
                tv_timer.setText("seconds remaining"  + millisUntilFinished / 1000);
            }
            public void onFinish(){
                tv_timer.setText("Time's up !");
            }
        }.start();
    }


}
