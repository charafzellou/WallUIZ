package walluiz.chaze.lukiles;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import walluiz.chaze.lukiles.walluiz.R;

public class WinActivity extends AppCompatActivity {
    private TextView money_earn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_win);

        money_earn = (TextView)findViewById(R.id.money_earn);

        SharedPreferences prefs = WinActivity.this.getSharedPreferences("money", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = prefs.edit();

        edit.putString("moneyEarn", WinActivity.this.money_earn.getText().toString());

        edit.apply();
    }
}
